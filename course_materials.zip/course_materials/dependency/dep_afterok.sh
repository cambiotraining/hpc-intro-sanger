rm *.txt
sbatch 001_create.sh
sbatch 002_move.sh
sbatch 003_move.sh
