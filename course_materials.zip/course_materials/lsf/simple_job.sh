#!/bin/bash

sleep 60 # hold for 60 seconds

echo "This job is running on:"
hostname
