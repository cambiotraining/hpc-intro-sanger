#!/bin/bash
#BJOBS -q normal  # name of the partition to run job on
#BJOBS -D /scratch/FIXME/hpc_workshop/  # working directory
#BJOBS -o logs/estimate_pi.log  # standard output file
#BJOBS -e logs/estimate_pi.err  # standard error file
#BJOBS -n1        # number of CPUs. Default: 1
#BJOBS -R "select[mem>1000] rusage [mem=1000] span[hosts=1]" # RAM memory part 1. Default: 100MB
#BJOBS -M 1000  # RAM memory part 2. Default: 100MB


Rscript FIXME
